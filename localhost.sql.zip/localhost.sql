-- phpMyAdmin SQL Dump
-- version phpStudy 2014
-- http://www.phpmyadmin.net
--
-- 主机: localhost
-- 生成日期: 2016 �?09 �?02 �?23:59
-- 服务器版本: 5.5.40
-- PHP 版本: 5.6.1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- 数据库: `course`
--
CREATE DATABASE `course` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `course`;

-- --------------------------------------------------------

--
-- 表的结构 `classe`
--

CREATE TABLE IF NOT EXISTS `classe` (
  `cla_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '班级id',
  `classe_id` char(9) NOT NULL COMMENT '班级编号',
  `classe_name` varchar(50) NOT NULL COMMENT '班级名称',
  `classe_rens` int(11) NOT NULL COMMENT '人数',
  `profess_id` char(9) NOT NULL COMMENT '专业编号',
  `classe_year` char(4) NOT NULL COMMENT '入学年份',
  PRIMARY KEY (`cla_id`),
  UNIQUE KEY `classe_id` (`classe_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='班级表' AUTO_INCREMENT=19 ;

--
-- 转存表中的数据 `classe`
--

INSERT INTO `classe` (`cla_id`, `classe_id`, `classe_name`, `classe_rens`, `profess_id`, `classe_year`) VALUES
(1, '134115091', 'B13软件工程班', 56, '29', '2013'),
(2, '134115101', 'B13软件工程(数字媒体)班', 56, '30', '2013'),
(3, '144115061', 'B14计算机科学与技术班', 55, '27', '2014'),
(4, '144115081', 'B14计算机科学与技术(信息技术教育方向)班', 54, '28', '2014'),
(5, '144215091', 'B14软件工程班', 50, '29', '2014'),
(6, '144215161', 'B14软件工程(软件测试)班', 47, '29', '2014'),
(7, '154115081', 'B15计算机科学与技术(信息技术教育方向)班', 43, '28', '2015'),
(8, '154215091', 'B15软件工程班', 48, '29', '2015'),
(9, '144116281', 'B14统计学1班', 35, '21', '2014'),
(10, '144116051', 'B14数学2班', 42, '22', '2014'),
(11, '134116281', 'B13统计学2班', 55, '21', '2013'),
(12, '154116051', 'B15数学1班', 47, '22', '2015'),
(13, '154225161', 'B15物理学班', 38, '20', '2015'),
(14, '134226151', 'B13电子信息班', 40, '23', '2013'),
(15, '144225161', 'B14物理学2班', 45, '20', '2014'),
(16, '154226151', 'B15电子信息班', 46, '23', '2015');

-- --------------------------------------------------------

--
-- 表的结构 `classroom`
--

CREATE TABLE IF NOT EXISTS `classroom` (
  `clar_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '教室id',
  `classroom_id` varchar(10) NOT NULL COMMENT '教室编号',
  `classroom_name` varchar(100) NOT NULL COMMENT '教室名称',
  `classroom_type` varchar(100) NOT NULL COMMENT '教室类型',
  `classroom_lh` varchar(50) NOT NULL COMMENT '楼号',
  `classroom_rs` int(11) NOT NULL COMMENT '容纳人数',
  PRIMARY KEY (`clar_id`),
  UNIQUE KEY `classroom_id` (`classroom_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='教室表' AUTO_INCREMENT=17 ;

--
-- 转存表中的数据 `classroom`
--

INSERT INTO `classroom` (`clar_id`, `classroom_id`, `classroom_name`, `classroom_type`, `classroom_lh`, `classroom_rs`) VALUES
(1, '1', '1201', '机房', '1', 44),
(2, '2', '1202', '机房', '1', 75),
(3, '3', '1204', '机房', '1', 75),
(4, '4', '1号阶3', '教室', '1', 200),
(5, '5', 'C314', '教室', '8', 135),
(6, '6', 'D521', '教室', '8', 135),
(7, '7', 'D531', '教室', '8', 135),
(8, '8', '1206', '机房', '1', 100),
(9, '9', 'c412', '教室', '8', 90),
(10, '10', 'c216', '教室', '8', 95),
(11, '11', '1212', '机房', '1', 100),
(12, '12', '1221', '教室', '1', 100),
(13, '13', 'c317', '教室', '8', 100),
(14, '14', 'b213', '教室', '8', 92),
(15, '15', '1207', '机房', '1', 50);

-- --------------------------------------------------------

--
-- 表的结构 `college`
--

CREATE TABLE IF NOT EXISTS `college` (
  `col_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '学院id',
  `college_id` char(2) NOT NULL COMMENT '学院编号',
  `college_name` varchar(20) NOT NULL COMMENT '学院名称',
  PRIMARY KEY (`col_id`),
  UNIQUE KEY `college_id` (`college_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='学院表' AUTO_INCREMENT=5 ;

--
-- 转存表中的数据 `college`
--

INSERT INTO `college` (`col_id`, `college_id`, `college_name`) VALUES
(1, '07', '信息科学与技术学院'),
(2, '05', '物理与电子工程学院'),
(3, '08', '数学统计学院');

-- --------------------------------------------------------

--
-- 表的结构 `course`
--

CREATE TABLE IF NOT EXISTS `course` (
  `cour_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '课程id',
  `course_id` char(8) NOT NULL COMMENT '课程编号',
  `course_name` varchar(25) NOT NULL COMMENT '课程名称',
  `course_xingz` varchar(10) NOT NULL COMMENT '课程性质',
  `course_testxs` varchar(8) NOT NULL COMMENT '考试形式',
  `course_zxs` int(11) NOT NULL COMMENT '周学时',
  `course_xuef` float NOT NULL COMMENT '学分',
  PRIMARY KEY (`cour_id`),
  UNIQUE KEY `course_id` (`course_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='课程表' AUTO_INCREMENT=18 ;

--
-- 转存表中的数据 `course`
--

INSERT INTO `course` (`cour_id`, `course_id`, `course_name`, `course_xingz`, `course_testxs`, `course_zxs`, `course_xuef`) VALUES
(1, '10000001', 'Flash二维动画', '基础课', '考查', 3, 3),
(2, '10000002', '软件工程', '专业课', '考试', 4, 4),
(3, '10000003', '计算机网络', '专业课', '考试', 4, 4),
(4, '10000005', ' 计算机专业英语', '专业课', '考试', 2, 2),
(5, '10000006', '平面UI设计', '专业课', '考查', 4, 4),
(6, '10000007', '网络广告创意与设计', '专业课', '考试', 4, 4),
(7, '10000008', '三大构成', '专业课', '考查', 4, 4),
(8, '10000009', '数据库系统概论', '专业课', '考试', 4, 3),
(9, '10000010', '电路基础', '专业课', '考试', 3, 3),
(10, '10000011', '高等数学', '基础课', '考查', 2, 3),
(11, '10000012', '离散数学', '专业课', '考试', 4, 4),
(12, '10000013', '力学', '专业课', '考试', 4, 3),
(13, '10000014', '物理工程', '专业课', '考试', 4, 4),
(14, '10000015', '线性代数', '专业课', '考试', 3, 3),
(15, '10000016', '统计学', '专业课', '考试', 2, 3),
(16, '10000017', '电子工程', '基础课', '考查', 3, 2);

-- --------------------------------------------------------

--
-- 表的结构 `plan`
--

CREATE TABLE IF NOT EXISTS `plan` (
  `pl_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '计划id',
  `plan_id` char(10) NOT NULL COMMENT '教学计划编号',
  `profess_id` char(9) NOT NULL COMMENT '专业编号',
  `plan_xq` varchar(2) NOT NULL COMMENT '计划学期',
  `course_id` char(8) NOT NULL COMMENT '课程编号',
  `plan_week` varchar(20) NOT NULL COMMENT '计划周数',
  PRIMARY KEY (`pl_id`),
  UNIQUE KEY `plan_id` (`plan_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='教学计划表' AUTO_INCREMENT=19 ;

--
-- 转存表中的数据 `plan`
--

INSERT INTO `plan` (`pl_id`, `plan_id`, `profess_id`, `plan_xq`, `course_id`, `plan_week`) VALUES
(1, '01', '29', '2', '10000002', '18'),
(2, '02', '27', '1', '10000005', '18'),
(3, '03', '26', '2', '10000006', '8'),
(4, '04', '28', '1', '10000001', '18'),
(5, '05', '30', '1', '10000003', '9'),
(6, '06', '31', '2', '10000004', '10'),
(7, '07', '27', '2', '10000007', '18'),
(8, '08', '26', '1', '10000008', '12'),
(9, '09', '30', '2', '10000009', '18'),
(10, '10', '20', '2', '10000010', '12'),
(11, '11', '21', '1', '10000011', '18'),
(12, '12', '22', '2', '10000012', '18'),
(13, '13', '23', '2', '10000013', '16'),
(14, '14', '20', '2', '10000014', '12'),
(15, '15', '21', '2', '10000015', '18'),
(16, '16', '22', '1', '10000016', '18'),
(17, '17', '23', '2', '10000017', '18');

-- --------------------------------------------------------

--
-- 表的结构 `profess`
--

CREATE TABLE IF NOT EXISTS `profess` (
  `pro_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '专业id',
  `profess_id` char(9) NOT NULL COMMENT '专业编号',
  `profess_name` varchar(50) NOT NULL COMMENT '名称',
  `profess_xuez` char(2) NOT NULL COMMENT '学制',
  `profess_xingz` char(10) NOT NULL COMMENT '性质',
  `profess_wl` char(2) NOT NULL COMMENT '文理',
  `college_id` char(2) NOT NULL COMMENT '学院编号',
  `profess_year` char(10) NOT NULL COMMENT '设置年份',
  PRIMARY KEY (`pro_id`),
  UNIQUE KEY `profess_id` (`profess_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='专业表' AUTO_INCREMENT=12 ;

--
-- 转存表中的数据 `profess`
--

INSERT INTO `profess` (`pro_id`, `profess_id`, `profess_name`, `profess_xuez`, `profess_xingz`, `profess_wl`, `college_id`, `profess_year`) VALUES
(1, '26', '软件工程(软件测试)', '4', '非师', '理', '07', '2013'),
(2, '27', '计算机科学与技术', '4', '师范', '理', '07', '2012'),
(3, '28', '计算机科学与技术(信息技术教育)', '4', '全日制本科', '理', '07', '2012'),
(4, '29', '软件工程', '4', '非师', '理', '07', '2013'),
(5, '30', '软件工程(数字媒体)', '4', '非师', '理', '07', '2012'),
(6, '31', '数字媒体技术', '4', '非师', '理', '07', '2015'),
(7, '21', '统计学', '4', '师范', '文', '08', '2013'),
(8, '20', '物理学', '4', '师范', '理', '05', '2014'),
(9, '22', '数学', '4', '师范', '文', '08', '2011'),
(10, '23', '物理学(电子方向)', '3', '师范', '理', '05', '2012');

-- --------------------------------------------------------

--
-- 表的结构 `sche`
--

CREATE TABLE IF NOT EXISTS `sche` (
  `sh_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '课表id',
  `sche_id` int(11) NOT NULL COMMENT '课表编号',
  `course_id` char(8) DEFAULT NULL COMMENT '课程编号',
  `classe_id` char(9) DEFAULT NULL COMMENT '班级编号',
  `teacher_id` char(6) DEFAULT NULL COMMENT '教师编号',
  `classroom_id` varchar(10) DEFAULT NULL COMMENT '教室编号',
  `sche_xq` char(9) DEFAULT NULL COMMENT '学期',
  `sche_tweek` int(11) DEFAULT NULL COMMENT '总周数',
  `sche_wsf` char(2) DEFAULT NULL COMMENT '周数是否分段',
  `sche_wstart` int(11) DEFAULT NULL COMMENT '分段起始周',
  `sche_wend` int(11) DEFAULT NULL COMMENT '分段结束周',
  `sche_wds` int(11) DEFAULT NULL COMMENT '单双周',
  `sche_jstart` int(11) DEFAULT NULL COMMENT '节次起始',
  `sche_jend` int(11) DEFAULT NULL COMMENT '节次结束',
  `sche_week` int(11) DEFAULT NULL COMMENT '星期',
  PRIMARY KEY (`sh_id`),
  UNIQUE KEY `sche_id` (`sche_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='课表' AUTO_INCREMENT=10 ;

--
-- 转存表中的数据 `sche`
--

INSERT INTO `sche` (`sh_id`, `sche_id`, `course_id`, `classe_id`, `teacher_id`, `classroom_id`, `sche_xq`, `sche_tweek`, `sche_wsf`, `sche_wstart`, `sche_wend`, `sche_wds`, `sche_jstart`, `sche_jend`, `sche_week`) VALUES
(1, 2, '10000001', '134115101', '100001', '1', '1', 18, '0', 1, 18, 0, 1, 2, 1),
(8, 3, '10000003', '144215161', '100003', '2', '1', 18, '0', 1, 18, 0, 5, 7, 3),
(2, 1, '10000010', '154225161', '500001', '3', '2', 18, '0', 1, 18, 0, 1, 2, 2),
(3, 7, '10000011', '144116051', '800002', '4', '2', 18, '0', 1, 18, 0, 5, 6, 5),
(4, 4, '10000013', '144225161', '500002', '5', '2', 18, '0', 1, 18, 0, 3, 4, 1),
(5, 5, '10000015', '154116051', '800001', '6', '1', 18, '0', 1, 18, 0, 3, 3, 4),
(6, 6, '10000003', '144215091', '100003', '7', '2', 18, '0', 1, 18, 0, 5, 6, 5),
(9, 0, '10000002', '144215161', '800001', '3', '1', 18, '0', 1, 18, 0, 1, 3, 3);

-- --------------------------------------------------------

--
-- 表的结构 `student`
--

CREATE TABLE IF NOT EXISTS `student` (
  `stu_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '学生id',
  `student_id` char(12) NOT NULL COMMENT '学号',
  `student_name` varchar(8) NOT NULL COMMENT '姓名',
  `student_sex` char(2) NOT NULL COMMENT '性别',
  `student_csrq` datetime NOT NULL COMMENT '出生日期',
  `student_jg` varchar(40) NOT NULL COMMENT '籍贯',
  `student_year` datetime NOT NULL COMMENT '入学年份',
  `student_iid` varchar(18) NOT NULL COMMENT '身份证号',
  `student_img` varchar(40) NOT NULL COMMENT '照片',
  `classe_id` char(9) NOT NULL COMMENT '班级编号',
  PRIMARY KEY (`stu_id`),
  UNIQUE KEY `student_id` (`student_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='学生表' AUTO_INCREMENT=27 ;

--
-- 转存表中的数据 `student`
--

INSERT INTO `student` (`stu_id`, `student_id`, `student_name`, `student_sex`, `student_csrq`, `student_jg`, `student_year`, `student_iid`, `student_img`, `classe_id`) VALUES
(1, '144215160001', '陈梦', '女', '2016-08-24 00:00:00', '河南省新密市', '0000-00-00 00:00:00', '522565133562356235', '4.jpg', '144215161'),
(2, '144215160004', '孟卓', '女', '0000-00-00 00:00:00', '河南省开封市', '0000-00-00 00:00:00', '', '', '144215161'),
(3, '144215160002', '殷思琪', '女', '0000-00-00 00:00:00', '河南省信阳市', '0000-00-00 00:00:00', '', '', '144215161'),
(4, '144215160007', '张浩', '男', '0000-00-00 00:00:00', '河南省许昌市', '0000-00-00 00:00:00', '', '', '144215161'),
(5, '144215160008', '张利飒', '女', '0000-00-00 00:00:00', '河南省许昌市', '0000-00-00 00:00:00', '', '', '144215161'),
(6, '144215160010', '李敏', '女', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', '', '', '144215161'),
(7, '144215160014', '史赵燕', '女', '0000-00-00 00:00:00', '河南省洛阳市', '0000-00-00 00:00:00', '', '', '144215161'),
(8, '144215160015', '李苏锐', '女', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', '', '', '144215161'),
(9, '144215160049', '华梦杰', '女', '0000-00-00 00:00:00', '河南省周口市', '0000-00-00 00:00:00', '', '', '144215161'),
(10, '144215090024', '李丙辰', '男', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', '', '', '144215091'),
(11, '144215090001', '史先锋', '男', '0000-00-00 00:00:00', '河南省商丘市', '0000-00-00 00:00:00', '156', '', '144215091'),
(12, '144215090002', '闫杰', '男', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', '', '', '144215091'),
(14, '144215090035', '游一', '女', '2016-08-22 00:00:00', '郑州中牟', '2016-09-04 00:00:00', '1234567889', '', '144215091'),
(15, '144215090021', '孟杨霞', '女', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', '4623165', '', '144215091'),
(16, '144215160019', '张文静', '女', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', '', '', '144215161'),
(17, '144215160038', '刘宁宁', '女', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', '', '', '144215161'),
(18, '144215160003', '钟可可', '女', '2016-08-03 00:00:00', '河南省周口市', '2016-08-02 00:00:00', '564216', '', '144215161'),
(13, '144215090004', '胡鹏飞', '男', '0000-00-00 00:00:00', '河南省新乡市', '0000-00-00 00:00:00', '', '', '144215091');

-- --------------------------------------------------------

--
-- 表的结构 `teacher`
--

CREATE TABLE IF NOT EXISTS `teacher` (
  `teach_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '教师id',
  `teacher_id` char(6) NOT NULL,
  `teacher_name` varchar(8) NOT NULL,
  `teacher_sex` char(2) NOT NULL,
  `teacher_zc` varchar(10) NOT NULL,
  `teacher_csrq` varchar(10) NOT NULL,
  `teacher_xl` varchar(8) NOT NULL,
  `college_id` char(2) NOT NULL,
  PRIMARY KEY (`teach_id`),
  UNIQUE KEY `teacher_id` (`teacher_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=15 ;

--
-- 转存表中的数据 `teacher`
--

INSERT INTO `teacher` (`teach_id`, `teacher_id`, `teacher_name`, `teacher_sex`, `teacher_zc`, `teacher_csrq`, `teacher_xl`, `college_id`) VALUES
(1, '100001', '王函', '女', '助教', '19850101', '硕士', '08'),
(2, '100002', '张红艳', '女', '助教', '19850101', '硕士', '07'),
(3, '100003', '张明慧', '女', '副教授', '19800101', '硕士', '07'),
(4, '100009', '楚志刚', '女', '教授', '19800101', '硕士', '07'),
(5, '100006', '海鹏娇', '女', '讲师', '19800101', '硕士', '07'),
(6, '100007', '王静', '女', '讲师', '19800102', '硕士', '07'),
(7, '100008', '宗书召', '男', '讲师', '19800101', '硕士', '07'),
(8, '800003', '陆雪琪', '女', '教授', '2016-08-02', '', '08'),
(9, '500003', '曾书书', '男', '副教授', '19800101', '硕士', '05'),
(10, '800001', '陈梦梦', '女', '讲师', '19800101', '硕士', '08'),
(11, '500002', '李洵', '男', '讲师', '19800101', '硕士', '05'),
(12, '800002', '张小凡', '男', '教授', '19900203', '硕士', '08'),
(14, '500001', '贝微微', '女', '讲师', '19890223', '硕士', '05');

-- --------------------------------------------------------

--
-- 表的结构 `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '用户id',
  `user_name` varchar(50) NOT NULL COMMENT '用户名',
  `user_pass` varchar(255) NOT NULL COMMENT '用户密码',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='用户表' AUTO_INCREMENT=3 ;

--
-- 转存表中的数据 `user`
--

INSERT INTO `user` (`id`, `user_name`, `user_pass`) VALUES
(1, 'admin', 'admin'),
(2, 'lisa', '123456');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
